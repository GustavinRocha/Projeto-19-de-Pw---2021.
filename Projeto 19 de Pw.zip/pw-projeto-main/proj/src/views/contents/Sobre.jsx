import React from "react"

const Sobre = props => (
    <div>
        <h1>Sobre</h1>
        <h2>Site sobre o filme Matrix</h2>
    </div>
)

export default Sobre