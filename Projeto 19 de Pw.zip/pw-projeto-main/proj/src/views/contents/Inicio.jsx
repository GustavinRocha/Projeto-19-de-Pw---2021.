import React from "react"

const Inicio = props => (
    <div>
        <h1>Projeto PWII</h1>
        <br />
        <h2>Matrix</h2> 
    </div>
)

export default Inicio