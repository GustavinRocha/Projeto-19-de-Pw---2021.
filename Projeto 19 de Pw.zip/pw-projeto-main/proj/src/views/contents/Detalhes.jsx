import React from "react"

const Detalhes = props => (
    <div>
        <h1>Detalhes</h1>
        
        <h2>Um jovem programador é atormentado por estranhos pesadelos nos quais sempre está 
            conectado por cabos a um imenso sistema de computadores do futuro. À medida que o sonho se repete, ele começa a 
            levantar dúvidas sobre a realidade. E quando encontra os misteriosos Morpheus e Trinity, ele descobre que é vítima do
             Matrix, um sistema inteligente e artificial que manipula a mente das pessoas e cria a ilusão de um mundo real enquanto 
             usa os cérebros e corpos dos indivíduos para produzir energia.</h2>
    </div>

)

export default Detalhes